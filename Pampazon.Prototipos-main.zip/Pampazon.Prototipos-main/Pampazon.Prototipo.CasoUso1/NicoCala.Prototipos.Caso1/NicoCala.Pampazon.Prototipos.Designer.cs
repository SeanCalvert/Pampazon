﻿namespace NicoCala.Prototipos.Caso1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            label5 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox7 = new TextBox();
            label7 = new Label();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            comboBox2 = new ComboBox();
            label9 = new Label();
            button7 = new Button();
            button2 = new Button();
            button3 = new Button();
            dateTimePicker1 = new DateTimePicker();
            label10 = new Label();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonHighlight;
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(355, 19);
            button1.Name = "button1";
            button1.Size = new Size(259, 173);
            button1.TabIndex = 1;
            button1.Text = "Listar órdenes de recepción";
            button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(12, 160);
            label1.Name = "label1";
            label1.Size = new Size(227, 32);
            label1.TabIndex = 4;
            label1.Text = "ID Orden Recepción";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 195);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(485, 27);
            textBox1.TabIndex = 5;
            //textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(12, 260);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(485, 27);
            textBox2.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(12, 225);
            label2.Name = "label2";
            label2.Size = new Size(119, 32);
            label2.TabIndex = 7;
            label2.Text = "ID Cliente";
            //label2.Click += label2_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(12, 325);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(485, 27);
            textBox3.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(12, 290);
            label3.Name = "label3";
            label3.Size = new Size(140, 32);
            label3.TabIndex = 9;
            label3.Text = "ID Producto";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(12, 513);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(485, 27);
            textBox4.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(12, 478);
            label4.Name = "label4";
            label4.Size = new Size(241, 32);
            label4.TabIndex = 11;
            label4.Text = "Descripción Producto";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(12, 417);
            label5.Name = "label5";
            label5.Size = new Size(84, 32);
            label5.TabIndex = 13;
            label5.Text = "Estado";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(10, 578);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(485, 27);
            textBox6.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(10, 543);
            label6.Name = "label6";
            label6.Size = new Size(109, 32);
            label6.TabIndex = 15;
            label6.Text = "Prioridad";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(10, 637);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(485, 27);
            textBox7.TabIndex = 18;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(10, 602);
            label7.Name = "label7";
            label7.Size = new Size(101, 32);
            label7.TabIndex = 17;
            label7.Text = "Posición";
            // 
            // button4
            // 
            button4.Location = new Point(12, 12);
            button4.Name = "button4";
            button4.Size = new Size(318, 29);
            button4.TabIndex = 20;
            button4.Text = "&Buscar";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(333, 733);
            button5.Name = "button5";
            button5.Size = new Size(318, 29);
            button5.TabIndex = 21;
            button5.Text = "&Limpiar";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(899, 511);
            button6.Name = "button6";
            button6.Size = new Size(318, 29);
            button6.TabIndex = 22;
            button6.Text = "&Volver";
            button6.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(12, 447);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(485, 28);
            comboBox2.TabIndex = 23;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(9, 667);
            label9.Name = "label9";
            label9.Size = new Size(1169, 57);
            label9.TabIndex = 24;
            label9.Text = "Se ha eliminado la orden de recepción seleccionada con éxito";
            //label9.Click += label9_Click;
            // 
            // button7
            // 
            button7.Location = new Point(12, 47);
            button7.Name = "button7";
            button7.Size = new Size(318, 29);
            button7.TabIndex = 33;
            button7.Text = "&Cargar";
            button7.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ButtonHighlight;
            button2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(686, 19);
            button2.Name = "button2";
            button2.Size = new Size(259, 173);
            button2.TabIndex = 34;
            button2.Text = "Crear orden de recepción";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ButtonHighlight;
            button3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(1015, 19);
            button3.Name = "button3";
            button3.Size = new Size(259, 173);
            button3.TabIndex = 35;
            button3.Text = "Confirmar Orden de Recepción";
            button3.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(12, 387);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(485, 27);
            dateTimePicker1.TabIndex = 36;
            dateTimePicker1.Value = new DateTime(2024, 5, 11, 0, 0, 0, 0);
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ButtonHighlight;
            label10.Location = new Point(12, 355);
            label10.Name = "label10";
            label10.Size = new Size(192, 32);
            label10.TabIndex = 37;
            label10.Text = "Fecha Recepción";
            // 
            // button8
            // 
            button8.Location = new Point(9, 733);
            button8.Name = "button8";
            button8.Size = new Size(318, 29);
            button8.TabIndex = 39;
            button8.Text = "&Crear";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(575, 511);
            button9.Name = "button9";
            button9.Size = new Size(318, 29);
            button9.TabIndex = 40;
            button9.Text = "&Confirmar";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(12, 82);
            button10.Name = "button10";
            button10.Size = new Size(318, 29);
            button10.TabIndex = 41;
            button10.Text = "&Actualizar";
            button10.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = SystemColors.ActiveCaptionText;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1286, 774);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox2);
            Controls.Add(label10);
            Controls.Add(textBox6);
            Controls.Add(label6);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button7);
            Controls.Add(label9);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(textBox7);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Orden de Recepción Eliminada con Éxito";
            //Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox4;
        private Label label4;
        private Label label5;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox7;
        private Label label7;
        private Button button4;
        private Button button5;
        private Button button6;
        private ComboBox comboBox2;
        private Label label9;
        private Button button7;
        private Button button2;
        private Button button3;
        private DateTimePicker dateTimePicker1;
        private Label label10;
        private Button button8;
        private Button button9;
        private Button button10;
    }
}
