﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pampazon.GrupoB.Prototipos.BKP
{
    internal class BKP
    {
        /* private void BotonBuscar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ComboBoxIDOrdenPreparacion.Text))
            {
                MessageBox.Show("El Id orden preparación no puede estar vacío");
                return;
            }

            if (string.IsNullOrWhiteSpace(ComboBoxIDCliente.Text))
            {
                MessageBox.Show("El id cliente no puede estar vacía");
                return;
            }

            //if (string.IsNullOrWhiteSpace(TxtIdProducto.Text))
            //{
            //    MessageBox.Show("El Id Producto no puede estar vacío");
            //    return;
            //}

            if (string.IsNullOrWhiteSpace(TxtFecha.Text))
            {
                MessageBox.Show("La fecha no puede estar vacía");
                return;
            }

            if (string.IsNullOrWhiteSpace(ComboBoxPrioridad.Text))
            {
                MessageBox.Show("La prioridad no puede estar vacía");
                return;
            }

            //if (string.IsNullOrWhiteSpace(TxtUbicacion.Text))
            //{
            //    MessageBox.Show("La ubicación no puede estar vacía");
            //    return;
            //}

            if (!DateTime.TryParse(TxtFecha.Text, out DateTime fecha))
            {
                MessageBox.Show("La fecha no es válida. Debe tener el siguiente formato: Día/Mes/Año ");
                return;
            }


            //var formListadoOrdenesSeleccionConfirmar = new ListadoOrdenesSeleccionConfirmarForm();
            ////formGestionarStock.Modelo = modelo;
            //formListadoOrdenesSeleccionConfirmar.ShowDialog();
        }*/
    }
}
