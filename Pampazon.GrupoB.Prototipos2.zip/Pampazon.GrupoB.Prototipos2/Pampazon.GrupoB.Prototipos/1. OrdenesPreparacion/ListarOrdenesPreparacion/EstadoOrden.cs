﻿namespace Pampazon.GrupoB.Prototipos.OrdenesPreparacion.ListarOrdenesPreparacion
{
    public enum EstadoOrden
    {
        Preparacion
    }
}