﻿namespace Pampazon.GrupoB.Prototipos
{
    public enum PrioridadA
    {
        Baja,
        Media,
        Alta
    }
}