﻿namespace Pampazon.GrupoB.Prototipos
{
    public class ProductoM
    {
        public string IDProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public int Cantidad { get; set; }
        public string Ubicacion { get; set; }
    }
}