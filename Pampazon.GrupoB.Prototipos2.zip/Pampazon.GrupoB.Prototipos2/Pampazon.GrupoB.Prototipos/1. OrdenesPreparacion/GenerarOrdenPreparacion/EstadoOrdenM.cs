﻿namespace Pampazon.GrupoB.Prototipos
{
    public enum EstadoOrdenM
    {
        Pendiente,
        EnSeleccion,
        Seleccionada,
        Preparada,
        Despachada
    }
}