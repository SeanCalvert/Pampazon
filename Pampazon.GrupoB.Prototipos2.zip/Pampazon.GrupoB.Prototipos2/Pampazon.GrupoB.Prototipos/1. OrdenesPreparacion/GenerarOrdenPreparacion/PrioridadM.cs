﻿namespace Pampazon.GrupoB.Prototipos
{
    public enum PrioridadM
    {
        Baja,
        Media,
        Alta
    }
}