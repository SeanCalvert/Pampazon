﻿namespace Pampazon.GrupoB.Prototipos
{
    public class OrdenesDeEntregaModelo
    {
    }
}