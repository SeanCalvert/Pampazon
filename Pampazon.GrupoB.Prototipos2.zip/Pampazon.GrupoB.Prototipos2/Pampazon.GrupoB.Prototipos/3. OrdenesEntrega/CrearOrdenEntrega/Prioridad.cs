﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.CrearOrdenEntrega
{
    public enum Prioridad
    {
        Baja,
        Media,
        Alta
    }
}