﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.CrearOrdenEntrega
{
    public class Producto
    {
        public string IDProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public int Cantidad { get; set; }
        public string Ubicacion { get; set; }
    }
}