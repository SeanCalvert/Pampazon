﻿namespace Pampazon.GrupoB.Prototipos._2._OrdenesSeleccion.ListarOrdenesSeleccion
{
    public enum PrioridadOrden
    {
        Baja,
        Media,
        Alta    
    }



}