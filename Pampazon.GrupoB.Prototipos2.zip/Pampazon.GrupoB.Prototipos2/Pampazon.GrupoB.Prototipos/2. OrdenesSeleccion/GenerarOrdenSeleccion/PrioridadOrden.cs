﻿namespace Pampazon.GrupoB.Prototipos._2._OrdenesSeleccion.GenerarOrdenSeleccion
{
    public enum PrioridadOrden
    {
        Baja,
        Media,
        Alta    
    }



}