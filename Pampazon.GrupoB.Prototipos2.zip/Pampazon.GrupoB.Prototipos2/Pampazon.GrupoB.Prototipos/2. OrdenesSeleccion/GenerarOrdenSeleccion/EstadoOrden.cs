﻿namespace Pampazon.GrupoB.Prototipos._2._OrdenesSeleccion.GenerarOrdenSeleccion
{
    public enum EstadoOrden
    {
            Pendiente,
            EnSeleccion,
            Seleccionada,
            Preparada,
            Despachada
    }
}