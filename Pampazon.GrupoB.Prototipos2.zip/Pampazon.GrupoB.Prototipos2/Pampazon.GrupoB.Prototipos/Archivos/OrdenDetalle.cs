﻿namespace Pampazon.GrupoB.Prototipos.Archivos
{
    public class OrdenDetalle
    {
        public string IdProducto { get; set; }
        public int Cantidad { get; set; }
    }
}