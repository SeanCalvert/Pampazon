﻿namespace Pampazon.GrupoB.Prototipos
{
    public class PaginaPrincipalModelo
    {
    }
}