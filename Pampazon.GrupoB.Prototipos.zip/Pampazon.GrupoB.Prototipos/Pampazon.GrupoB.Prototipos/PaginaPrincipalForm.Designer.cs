﻿namespace Pampazon.GrupoB.Prototipos
{
    partial class PaginaPrincipalForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BotonOrdenesPreparacion = new Button();
            BotonOrdenesSeleccion = new Button();
            BotonOrdenesEntrega = new Button();
            SuspendLayout();
            // 
            // BotonOrdenesPreparacion
            // 
            BotonOrdenesPreparacion.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            BotonOrdenesPreparacion.Location = new Point(119, 258);
            BotonOrdenesPreparacion.Margin = new Padding(4, 5, 4, 5);
            BotonOrdenesPreparacion.Name = "BotonOrdenesPreparacion";
            BotonOrdenesPreparacion.Size = new Size(281, 252);
            BotonOrdenesPreparacion.TabIndex = 2;
            BotonOrdenesPreparacion.Text = "Órdenes de Preparación";
            BotonOrdenesPreparacion.UseVisualStyleBackColor = true;
            BotonOrdenesPreparacion.Click += BotonOrdenesPreparacion_Click;
            // 
            // BotonOrdenesSeleccion
            // 
            BotonOrdenesSeleccion.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            BotonOrdenesSeleccion.Location = new Point(430, 258);
            BotonOrdenesSeleccion.Margin = new Padding(4, 5, 4, 5);
            BotonOrdenesSeleccion.Name = "BotonOrdenesSeleccion";
            BotonOrdenesSeleccion.Size = new Size(281, 252);
            BotonOrdenesSeleccion.TabIndex = 3;
            BotonOrdenesSeleccion.Text = "Órdenes de Selección";
            BotonOrdenesSeleccion.UseVisualStyleBackColor = true;
            BotonOrdenesSeleccion.Click += BotonOrdenesSeleccion_Click;
            // 
            // BotonOrdenesEntrega
            // 
            BotonOrdenesEntrega.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            BotonOrdenesEntrega.Location = new Point(744, 258);
            BotonOrdenesEntrega.Margin = new Padding(4, 5, 4, 5);
            BotonOrdenesEntrega.Name = "BotonOrdenesEntrega";
            BotonOrdenesEntrega.Size = new Size(281, 252);
            BotonOrdenesEntrega.TabIndex = 4;
            BotonOrdenesEntrega.Text = "Órdenes de Entrega";
            BotonOrdenesEntrega.UseVisualStyleBackColor = true;
            BotonOrdenesEntrega.Click += BotonOrdenesEntrega_Click;
            // 
            // PaginaPrincipalForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Fondo_casos_de_uso;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1143, 750);
            Controls.Add(BotonOrdenesEntrega);
            Controls.Add(BotonOrdenesSeleccion);
            Controls.Add(BotonOrdenesPreparacion);
            Margin = new Padding(4, 5, 4, 5);
            Name = "PaginaPrincipalForm";
            Text = "Página Principal";
            Load += PaginaPrincipal_Load;
            ResumeLayout(false);
        }

        #endregion
        private Button BotonOrdenesPreparacion;
        private Button BotonOrdenesSeleccion;
        private Button BotonOrdenesEntrega;
    }
}
