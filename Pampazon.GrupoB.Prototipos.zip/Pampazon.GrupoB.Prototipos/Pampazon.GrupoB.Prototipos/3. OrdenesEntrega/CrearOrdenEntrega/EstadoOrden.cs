﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.DespachoOrdenEntrega
{
    public enum EstadoOrden
    {
        Pendiente,
        EnSeleccion,
        Seleccionada,
        Preparada,
        Despachada
    }
}