﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.CrearOrdenEntrega
{
    public enum EstadoOrden
    {
        Pendiente,
        EnSeleccion,
        Seleccionada,
        Preparada,
        Despachada
    }
}