﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.DespachoOrdenEntrega
{
    public enum Prioridad
    {
        Baja,
        Media,
        Alta
    }
}