﻿namespace Pampazon.GrupoB.Prototipos._2._OrdenesSeleccion.GenerarOrdenSeleccion
{
    public class OrdenDetalle
    {
        public string IdProducto { get; set; }
        public int Cantidad { get; set; }
    }
}