﻿namespace Pampazon.GrupoB.Prototipos
{
    public class CrearOrdenSeleccionModelo
    {
    }
}