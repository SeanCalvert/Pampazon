﻿namespace Pampazon.GrupoB.Prototipos._2._OrdenesSeleccion.ListarOrdenesSeleccion
{
    public enum EstadoOrden
    {
        Pendiente,
        EnSeleccion,
        Seleccionada,
        Preparada,
        Despachada
    }
}