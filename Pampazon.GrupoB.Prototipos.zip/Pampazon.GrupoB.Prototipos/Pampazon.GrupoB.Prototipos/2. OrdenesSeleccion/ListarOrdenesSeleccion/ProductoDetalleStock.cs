﻿namespace Pampazon.GrupoB.Prototipos._2._OrdenesSeleccion.ListarOrdenesSeleccion
{
    public class ProductoDetalleStock
    {
        public string Ubicacion {  get; set; }
        public int Cantidad { get; set; }

    }
}