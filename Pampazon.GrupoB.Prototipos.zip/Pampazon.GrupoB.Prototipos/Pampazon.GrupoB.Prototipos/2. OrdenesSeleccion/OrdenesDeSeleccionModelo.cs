﻿namespace Pampazon.GrupoB.Prototipos
{
    public class OrdenesDeSeleccionModelo
    {
    }
}