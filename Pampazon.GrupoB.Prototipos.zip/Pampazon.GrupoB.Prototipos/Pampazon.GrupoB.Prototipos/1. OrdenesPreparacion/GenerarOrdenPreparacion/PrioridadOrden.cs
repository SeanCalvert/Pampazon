﻿namespace Pampazon.GrupoB.Prototipos._1._OrdenesPreparacion.GenerarOrdenPreparacion
{
    public enum PrioridadOrden
    {
        Baja,
        Media,
        Alta
    }



}