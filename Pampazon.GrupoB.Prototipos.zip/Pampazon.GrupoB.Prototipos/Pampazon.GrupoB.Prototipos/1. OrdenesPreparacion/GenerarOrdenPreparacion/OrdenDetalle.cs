﻿namespace Pampazon.GrupoB.Prototipos._1._OrdenesPreparacion.GenerarOrdenPreparacion
{
    public class OrdenDetalle
    {
        public string IdProducto { get; set; }
        public int Cantidad { get; set; }
    }
}