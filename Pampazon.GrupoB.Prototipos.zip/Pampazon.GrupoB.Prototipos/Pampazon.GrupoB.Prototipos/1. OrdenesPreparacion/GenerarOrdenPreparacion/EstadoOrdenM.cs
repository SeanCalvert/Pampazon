﻿namespace Pampazon.GrupoB.Prototipos
{
    public enum EstadoOrdenM
    {    
        Preparada    
    }
}