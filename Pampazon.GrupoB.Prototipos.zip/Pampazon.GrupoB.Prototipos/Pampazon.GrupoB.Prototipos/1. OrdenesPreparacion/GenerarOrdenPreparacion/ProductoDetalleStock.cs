﻿namespace Pampazon.GrupoB.Prototipos._1._OrdenesPreparacion.GenerarOrdenPreparacion
{
    public class ProductoDetalleStock
    {
        public string Ubicacion {  get; set; }
        public int Cantidad { get; set; }

    }
}