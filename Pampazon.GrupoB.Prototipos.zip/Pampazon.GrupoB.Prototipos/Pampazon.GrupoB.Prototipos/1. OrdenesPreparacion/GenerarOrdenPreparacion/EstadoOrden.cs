﻿namespace Pampazon.GrupoB.Prototipos._1._OrdenesPreparacion.GenerarOrdenPreparacion
{
    public enum EstadoOrden
    {
        Preparada
    }
}