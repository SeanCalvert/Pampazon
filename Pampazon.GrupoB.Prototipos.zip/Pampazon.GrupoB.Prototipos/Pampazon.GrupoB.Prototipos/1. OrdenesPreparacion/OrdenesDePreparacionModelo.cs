﻿namespace Pampazon.GrupoB.Prototipos
{
    public class OrdenesDePreparacionModelo
    {
    }
}