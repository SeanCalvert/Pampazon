﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pampazon.GrupoB.Prototipos.OrdenesPreparacion.ListarOrdenesPreparacion
{
    public class Cliente
    {
        public string IDCliente { get; set; } 
        public string DescripcionCliente {  get; set; } 
    }
}
