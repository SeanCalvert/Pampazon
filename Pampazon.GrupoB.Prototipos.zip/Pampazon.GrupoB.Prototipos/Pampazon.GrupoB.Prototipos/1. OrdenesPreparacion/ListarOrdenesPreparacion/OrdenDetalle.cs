﻿namespace Pampazon.GrupoB.Prototipos.OrdenesPreparacion.ListarOrdenesPreparacion
{
    public class OrdenDetalle
    {
        public string IdProducto { get; set; }
        public int Cantidad { get; set; }
    }
}