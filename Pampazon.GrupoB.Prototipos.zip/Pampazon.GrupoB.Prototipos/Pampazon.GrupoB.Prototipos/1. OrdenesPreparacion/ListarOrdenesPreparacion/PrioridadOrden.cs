﻿namespace Pampazon.GrupoB.Prototipos.OrdenesPreparacion.ListarOrdenesPreparacion
{
    public enum PrioridadOrden
    {
        Baja,
        Media,
        Alta
    }



}