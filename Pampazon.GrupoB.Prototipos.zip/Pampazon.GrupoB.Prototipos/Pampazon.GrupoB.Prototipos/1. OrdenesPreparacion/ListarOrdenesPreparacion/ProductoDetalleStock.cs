﻿namespace Pampazon.GrupoB.Prototipos.OrdenesPreparacion.ListarOrdenesPreparacion
{
    public class ProductoDetalleStock
    {
        public string Ubicacion {  get; set; }
        public int Cantidad { get; set; }

    }
}