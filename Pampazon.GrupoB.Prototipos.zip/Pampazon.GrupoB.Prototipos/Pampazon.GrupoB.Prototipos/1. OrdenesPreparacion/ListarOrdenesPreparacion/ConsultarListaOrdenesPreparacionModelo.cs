﻿namespace Pampazon.GrupoB.Prototipos
{
    public class ConsultarListaOrdenesPreparacionModelo
    {
    }
}