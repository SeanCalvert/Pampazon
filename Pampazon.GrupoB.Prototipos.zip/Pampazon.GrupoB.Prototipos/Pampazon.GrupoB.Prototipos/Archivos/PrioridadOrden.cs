﻿namespace Pampazon.GrupoB.Prototipos.Archivos

{
    public enum PrioridadOrden
    {
        Baja,
        Media,
        Alta
    }
}