﻿namespace Pampazon.GrupoB.Prototipos.Archivos

{
    public class Cliente
    {
        public string IDCliente { get; set; }
        public string CUIT { get; set; }
        public string NombreCliente { get; set; }
    }
}