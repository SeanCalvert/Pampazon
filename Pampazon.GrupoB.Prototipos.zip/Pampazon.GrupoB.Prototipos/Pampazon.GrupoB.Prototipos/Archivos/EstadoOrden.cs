﻿namespace Pampazon.GrupoB.Prototipos.Archivos
{
    public enum EstadoOrden
    {
        Pendiente,
        EnSeleccion,
        Seleccionada,
        Preparada,
        Despachada
    }
}