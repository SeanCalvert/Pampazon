﻿
using Pampazon.GrupoB.Prototipos.Archivos;

namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.DespachoOrdenEntrega
{
    public class DespachoOrdenEntregaModelo
    {
        public List<OrdenEntrega> OrdenesEntrega { get; set; }
        public List<OrdenDespacho> OrdenesDespacho { get; set; }
        public List<OrdenPreparacion> OrdenesPreparacion { get; set; }
        public List<Producto> Productos { get; set; }

        public List<OrdenEntrega> ordenesEntregaEstadoPreparadas { get; set; }


        public DespachoOrdenEntregaModelo()
        {
            OrdenesEntrega = new();
            OrdenesPreparacion = new();
            Productos = new();

            foreach (var os in ArchivoOrdenesEntrega.OrdenesEntrega)
            {
                var osModelo = new OrdenEntrega()
                {
                    FechaCreacion = os.FechaCreacion,
                    IDOrdenEntrega = os.IDOrdenEntrega,
                    OrdenesPreparacion = new List<OrdenPreparacion>() // Asegúrate de inicializar la lista
                };

                foreach (var op in os.IDsOrdenesPreparacion)
                {
                    var opArchivo = ArchivoOrdenesPreparacion.OrdenesPreparacion.FirstOrDefault(orden => orden.IDOrdenPreparacion == op.ToString());

                    if (opArchivo != null) // Asegúrate de que la orden de preparación exista
                    {
                        var opModelo = new OrdenPreparacion()
                        {
                            IDOrdenPreparacion = opArchivo.IDOrdenPreparacion,
                            IdCliente = opArchivo.IdCliente,
                            DescripcionCliente = opArchivo.DescripcionCliente,
                            FechaOrdenRecepcion = opArchivo.FechaOrdenRecepcion,
                            Estado = (EstadoOrden)opArchivo.Estado,
                            Prioridad = (Prioridad)opArchivo.Prioridad,
                            Productos = new List<Producto>() // Asegúrate de inicializar la lista
                        };

                        foreach (var prod in opArchivo.Productos)
                        {
                            var prodArchivo = ArchivoProductos.Productos.FirstOrDefault(producto => producto.IDProducto == prod.IdProducto.ToString());

                            if (prodArchivo != null) // Asegúrate de que el producto exista
                            {
                                var prodModelo = new Producto()
                                {
                                    IDProducto = prodArchivo.IDProducto,
                                    IdCliente = prodArchivo.IdCliente,
                                    Cantidad = prodArchivo.Cantidad,
                                    DescripcionProducto = prodArchivo.DescripcionProducto,
                                    Ubicaciones = new List<ProductoDetalleStock>() // Asegúrate de inicializar la lista
                                };

                                foreach (var ubi in prodArchivo.Ubicaciones)
                                {
                                    var ubiModelo = new ProductoDetalleStock()
                                    {
                                        Ubicacion = ubi.Ubicacion,
                                        Cantidad = ubi.Cantidad
                                    };

                                    prodModelo.Ubicaciones.Add(ubiModelo); // Agrega la ubicación a la lista del producto
                                }

                                opModelo.Productos.Add(prodModelo); // Agrega el producto a la lista de la orden de preparación
                            }
                        }

                        osModelo.OrdenesPreparacion.Add(opModelo); // Agrega la orden de preparación a la lista de la orden de selección
                    }
                }

                OrdenesEntrega.Add(osModelo); // Agrega la orden de selección a la lista principal
            }

            ordenesEntregaEstadoPreparadas = new();

            foreach (var oe in OrdenesEntrega)
            {
                if (oe.OrdenesPreparacion.Any(op => op.Estado.ToString() == "Preparada"))
                {
                    ordenesEntregaEstadoPreparadas.Add(oe);
                }
            }
        }




        internal string AltaOrdenDespacho(ListView.ListViewItemCollection ordenesPreparacionAAgregar)
        {
            new OrdenDespacho
            {
                IDOrdenDespacho = obtenerNuevoIDOrdenEntrega(),
                FechaCreacion = DateTime.Now,
                OrdenesPreparacion = new List<OrdenPreparacion>()
            };

            foreach (ListViewItem ordenpreparacionAAgregar in ordenesPreparacionAAgregar)
            {
                var nuevaOrdenPreparacion = new OrdenPreparacion
                {
                    //Obtegno el ID de la orden de preparacion
                    IDOrdenPreparacion = ordenpreparacionAAgregar.Text.ToString(),
                    IdCliente = ordenpreparacionAAgregar.SubItems[0].ToString(),
                    //Agregar fecha


                };
            }

            return null;
        }




        private string obtenerNuevoIDOrdenEntrega()
        {
            // Ver si la orden que voy a cargar no es la primera
            if (OrdenesDespacho.Count > 0)
            {
                // Ordena la lista por IDOrdenEntrega en orden descendente
                OrdenesDespacho.Sort((a, b) => b.IDOrdenDespacho.CompareTo(a.IDOrdenDespacho));

                // Obtiene el último IDOrdenEntrega
                // Al estar ordenado de forma descendente, esta en el index [0]
                string ultimoID = OrdenesDespacho[0].IDOrdenDespacho;

                // Con el substring agarro los numeros del ID, no me importan las letras
                // Con el int.Parse lo convierto a numero para poder sumarle 1
                int IDNumeros = int.Parse(ultimoID.Substring(3));

                //Obtengo el siguiente numero ID
                int NuevoNumero = IDNumeros + 1;

                //Ahora concateno la parte de letras del ID con la parte numerica transformada
                //Substring (0,3) me trae el "AA-" y despues el NumeroNuevo son los "0000"
                string nuevoID = ultimoID.Substring(0, 3) + NuevoNumero.ToString();

                // Devuelve el nuevo ID como cadena
                return nuevoID;
            }
            else
            {
                // Si la lista está vacía, devuelve un valor predeterminado (por ejemplo, "1")
                return "OE-0001";
            }
        }
    }
}

