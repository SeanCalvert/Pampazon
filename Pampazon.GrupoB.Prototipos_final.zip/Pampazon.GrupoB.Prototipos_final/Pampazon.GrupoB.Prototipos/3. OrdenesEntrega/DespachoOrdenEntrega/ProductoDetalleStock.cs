﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.DespachoOrdenEntrega

{
    public class ProductoDetalleStock
    {
        public string Ubicacion {  get; set; }
        public int Cantidad { get; set; }

    }
}