﻿using Pampazon.GrupoB.Prototipos.Archivos;

namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.CrearOrdenEntrega
{
    public class CrearOrdenEntregaModelo
    {

        // Propiedad para almacenar las órdenes de preparación
        public List<OrdenPreparacion> OrdenesPreparacion { get; set; }
        public List<OrdenEntrega> OrdenesEntrega { get; set; }

        public List<Producto> Productos { get; set; }

        public CrearOrdenEntregaModelo()
        {
            OrdenesPreparacion = new List<OrdenPreparacion>();
            Productos = new List<Producto>();

            foreach (var op in ArchivoOrdenesPreparacion.OrdenesPreparacion)
            {
                    var opModelo = new OrdenPreparacion()
                    {
                        IDOrdenPreparacion = op.IDOrdenPreparacion,
                        IdCliente = op.IdCliente,
                        DescripcionCliente = op.DescripcionCliente,
                        FechaOrdenRecepcion = op.FechaOrdenRecepcion,
                        Estado = (EstadoOrden)op.Estado,
                        Prioridad = (Prioridad)op.Prioridad,
                        Productos = new List<Producto>() // Asegúrate de inicializar la lista
                    };

                    foreach (var prod in op.Productos)
                    {
                        var prodArchivo = ArchivoProductos.Productos.FirstOrDefault(producto => producto.IDProducto == prod.IdProducto.ToString());

                        if (prodArchivo != null) // Asegúrate de que el producto exista
                        {
                            var prodModelo = new Producto()
                            {
                                IDProducto = prodArchivo.IDProducto,
                                IdCliente = prodArchivo.IdCliente,
                                Cantidad = prodArchivo.Cantidad,
                                DescripcionProducto = prodArchivo.DescripcionProducto,
                                Ubicaciones = new List<ProductoDetalleStock>() // Asegúrate de inicializar la lista
                            };

                            foreach (var ubi in prodArchivo.Ubicaciones)
                            {
                                var ubiModelo = new ProductoDetalleStock()
                                {
                                    Ubicacion = ubi.Ubicacion,
                                    Cantidad = ubi.Cantidad
                                };

                                prodModelo.Ubicaciones.Add(ubiModelo); // Agrega la ubicación a la lista del producto
                            }

                            opModelo.Productos.Add(prodModelo); // Agrega el producto a la lista de la orden de preparación
                        }
                    }

                    OrdenesPreparacion.Add(opModelo); // Agrega la orden de preparación a la lista de la orden de selección
            }
        }
        




        private string obtenerNuevoIDOrdenEntrega()
        {
            // Ver si la orden que voy a cargar no es la primera
            if (OrdenesEntrega.Count > 0)
            {
                // Ordena la lista por IDOrdenEntrega en orden descendente
                OrdenesEntrega.Sort((a, b) => b.IDOrdenEntrega.CompareTo(a.IDOrdenEntrega));

                // Obtiene el último IDOrdenEntrega
                // Al estar ordenado de forma descendente, esta en el index [0]
                string ultimoID = OrdenesEntrega[0].IDOrdenEntrega;

                // Con el substring agarro los numeros del ID, no me importan las letras
                // Con el int.Parse lo convierto a numero para poder sumarle 1
                int IDNumeros = int.Parse(ultimoID.Substring(3));

                //Obtengo el siguiente numero ID
                int NuevoNumero = IDNumeros + 1;

                //Ahora concateno la parte de letras del ID con la parte numerica transformada
                //Substring (0,3) me trae el "AA-" y despues el NumeroNuevo son los "0000"
                string nuevoID = ultimoID.Substring(0, 3) + NuevoNumero.ToString();

                // Devuelve el nuevo ID como cadena
                return nuevoID;
            }
            else
            {
                // Si la lista está vacía, devuelve un valor predeterminado (por ejemplo, "1")
                return "OE-0001";
            }
        }

        internal string AltaOrdenEntrega(List<string> ordenesPreparacionAAgregar)
        {
            new OrdenesEntrega.DespachoOrdenEntrega.OrdenEntrega
            {
                IDOrdenEntrega = obtenerNuevoIDOrdenEntrega(),
                FechaCreacion = DateTime.Now,
            };

            return null;
        }

    }
}