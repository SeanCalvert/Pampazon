﻿namespace Pampazon.GrupoB.Prototipos.OrdenesEntrega.CrearOrdenEntrega
{
    public class ProductoDetalleStock
    {
        public string Ubicacion {  get; set; }
        public int Cantidad { get; set; }

    }
}